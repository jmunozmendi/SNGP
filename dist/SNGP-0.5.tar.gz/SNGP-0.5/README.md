# SNGP

Implementation of Spectral-normalized Neural Gaussian Process (SNGP) in PyTorch.


pip install SNGP
