from .sngp_info import SNGPInfo
